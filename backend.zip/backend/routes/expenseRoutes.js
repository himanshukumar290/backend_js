const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const Expense = require("../models/Expense");

// @route   POST /api/expenses
// @desc    Add a new expense
// @access  Private
router.post("/", auth, async (req, res) => {
    try {
        const { amount, category, description, paymentMethod, date } = req.body;

        if (!amount || !category || !paymentMethod || !date) {
            return res.status(400).json({ message: "Please fill in all required fields" });
        }

        if (!req.user || !req.user.id) {
            return res.status(401).json({ message: "Unauthorized: User not found" });
        }

        const newExpense = new Expense({
            user: req.user.id,
            amount,
            category,
            description,
            paymentMethod,
            date,
        });

        await newExpense.save();
        res.status(201).json(newExpense);
    } catch (error) {
        console.error("Error adding expense:", error);
        res.status(500).json({ message: "Server Error", error: error.message });
    }
});

module.exports = router;
