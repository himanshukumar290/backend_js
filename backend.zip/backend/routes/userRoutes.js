const express = require('express');
const {
    registerUser,
    loginUser,
    getUserDetails,
    getAllUsers,
    updateUser,
    deleteUser
} = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/register', registerUser);
router.post('/login', loginUser);
router.get('/profile', protect, getUserDetails); // Protected route
router.get('/all', protect, getAllUsers); // Protected route to get all users
router.put('/update', protect, updateUser); // Protected update route
router.delete('/delete/:id', protect, deleteUser); // Protected delete route

module.exports = router;
