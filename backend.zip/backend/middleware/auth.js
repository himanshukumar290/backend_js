const jwt = require("jsonwebtoken");
const User = require("../models/User"); // Import User model

module.exports = async (req, res, next) => {
    const token = req.header("Authorization");

    if (!token) {
        return res.status(401).json({ message: "Access Denied: No Token Provided" });
    }

    try {
        const decoded = jwt.verify(token.replace("Bearer ", ""), process.env.JWT_SECRET);
        
        // Fetch the full user object from the database
        const user = await User.findById(decoded.id);
        if (!user) {
            return res.status(401).json({ message: "Unauthorized: User not found" });
        }

        req.user = { id: user._id, username: user.username }; // Attach user info
        next();
    } catch (error) {
        console.error("Authentication Error:", error);
        res.status(400).json({ message: "Invalid Token" });
    }
};
