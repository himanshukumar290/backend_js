const Expense = require("../models/Expense");

// Add Expense
exports.addExpense = async (req, res) => {
    try {
        const { amount, category, description, paymentMethod, date } = req.body;
        const newExpense = new Expense({ user: req.user.id, amount, category, description, paymentMethod, date });
        await newExpense.save();
        res.status(201).json(newExpense);
    } catch (error) {
        res.status(500).json({ message: "Error adding expense", error });
    }
};

// Get Expenses
exports.getExpenses = async (req, res) => {
    try {
        const expenses = await Expense.find({ user: req.user.id }).sort({ date: -1 });
        res.status(200).json(expenses);
    } catch (error) {
        res.status(500).json({ message: "Error fetching expenses", error });
    }
};

// Update Expense
exports.updateExpense = async (req, res) => {
    try {
        const expense = await Expense.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.status(200).json(expense);
    } catch (error) {
        res.status(500).json({ message: "Error updating expense", error });
    }
};

// Delete Expense
exports.deleteExpense = async (req, res) => {
    try {
        await Expense.findByIdAndDelete(req.params.id);
        res.status(200).json({ message: "Expense deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error deleting expense", error });
    }
};
