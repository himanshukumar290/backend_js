const express = require('express');
const connectDB = require('./config/db');
const User = require('./models/User'); // Import User model
const userRoutes = require('./routes/userRoutes');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const expenseRoutes = require("./routes/expenseRoutes");

dotenv.config();
connectDB();

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/users', userRoutes);
app.use("/api/expenses", expenseRoutes);

const SECRET_KEY = process.env.JWT_SECRET || "your_secret_key";

// ✅ Login API (Generates JWT & Returns Full User Details)
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await User.findOne({ username });

        if (!user) {
            return res.status(401).json({ message: "User not found" });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: "Invalid credentials" });
        }

        const token = jwt.sign({ id: user._id, username: user.username }, SECRET_KEY, { expiresIn: "1h" });

        res.json({
            token,
            user: {
                id: user._id,
                username: user.username,
                name: user.name,
                email: user.email,
                phone: user.phone,
                dob: user.dob,
                bio: user.bio,
                dateOfJoining: user.dateOfJoining // date of joining
            }
        });

    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

// ✅ Get User Details from Token (Fetch from DB)
app.get('/api/user', async (req, res) => {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) return res.status(401).json({ message: "Unauthorized" });

    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        const user = await User.findById(decoded.id).select("-password"); // Exclude password

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        res.json({
            id: user._id,
            username: user.username,
            name: user.name,
            email: user.email,
            phone: user.phone,
            dob: user.dob,
            bio: user.bio,
            dateOfJoining: user.dateOfJoining
        });
    } catch (error) {
        res.status(403).json({ message: "Invalid token" });
    }
});

// Global Error Handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Something went wrong!' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
